from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import sqlite3

import pandas as pd
import pytest

from historical_data.api import HistoricalDataService
from historical_data.models import InstrumentConfig, ProviderResult
from turtle_detector.alerts.daily_notifier import LogNotifier
from turtle_detector.daily_cli import main as daily_main
from inv_trend_core.signals import SignalEvent
from inv_trend_application import DailyMarketScanService
from turtle_detector.models import AssetConfig, Market
from turtle_detector.storage.daily_signal_repository import SQLiteDailySignalRepository


UTC = timezone.utc


def _instrument(symbol: str, *, status: str = "CURATED") -> InstrumentConfig:
    return InstrumentConfig(
        symbol=symbol, source_symbol=symbol, instrument_id=f"{symbol}.TEST.SPOT",
        asset_class="crypto", market="test", venue="test", instrument_type="spot",
        quote_currency="USD", currency="USD", timezone="UTC", session_timezone="UTC",
        session="24x7", primary_source="fake", earliest_valid_date="2020-01-01",
        adjustment_policy="none", adjustment_method="none",
    )


def _asset(symbol: str) -> AssetConfig:
    return AssetConfig(
        symbol=symbol, instrument=f"{symbol}_TEST", market=Market.CRYPTO,
        data_source="fake", timeframes=("D1",), price_type="spot", adjustment="none",
    )


def _bars(*, quality: str = "CURATED") -> pd.DataFrame:
    closes = [100.0] * 79 + [111.0]
    frame = pd.DataFrame({
        "timestamp": pd.date_range("2024-01-30", periods=80, freq="D", tz="UTC"),
        "open": closes, "high": [110.0] * 79 + [111.0],
        "low": [90.0] * 79 + [100.0], "close": closes,
        "volume": [1000.0] * 80, "is_complete": [True] * 80,
    })
    frame["quality_status"] = quality
    return frame


class FakeProvider:
    name = "fake"

    def __init__(self, *, fail: set[str] | None = None) -> None:
        self.fail = fail or set()
        self.requests = []

    def fetch(self, request):
        self.requests.append(request)
        if request.instrument.symbol in self.fail:
            raise RuntimeError("provider timeout")
        source = _bars()
        stamps = pd.to_datetime(source["timestamp"], utc=True)
        frame = source.loc[(stamps >= pd.Timestamp(request.start)) & (stamps <= pd.Timestamp(request.end))].copy()
        return ProviderResult(frame, request.instrument.source_symbol, self.name, "test")


def _service(tmp_path: Path, symbols=("AAA",), *, fail=None, now_day=19):
    instruments = {symbol: _instrument(symbol) for symbol in symbols}
    provider = FakeProvider(fail=fail)
    historical = HistoricalDataService(
        tmp_path / "data", instruments=instruments, providers={"fake": provider}
    )
    scanner = DailyMarketScanService(
        data_root=tmp_path / "data", output_dir=tmp_path / "out",
        signal_log_dir=tmp_path / "logs", assets={s: _asset(s) for s in symbols},
        historical_service=historical,
        now=lambda: datetime(2024, 4, now_day, 12, tzinfo=UTC),
    )
    return scanner, provider


def test_bootstrap_is_idempotent_in_sqlite_and_log(tmp_path: Path) -> None:
    scanner, provider = _service(tmp_path)
    first = scanner.run(bootstrap_days=80)
    assert first.exit_code == 0
    assert first.snapshot["summary"]["signals_new"] == 4
    assert SQLiteDailySignalRepository(first.database_path).signal_count() == 4
    log = tmp_path / "logs" / "2024-04-19.jsonl"
    assert len(log.read_text(encoding="utf-8").splitlines()) == 4

    second = scanner.run(bootstrap_days=80)
    assert second.snapshot["summary"]["signals_new"] == 0
    assert second.snapshot["summary"]["signals_duplicate"] == 4
    assert SQLiteDailySignalRepository(second.database_path).signal_count() == 4
    assert len(log.read_text(encoding="utf-8").splitlines()) == 4
    # The second run intentionally re-fetches the bounded revision overlap;
    # content addressing keeps the dataset and signals unchanged.
    assert len(provider.requests) == 2


def test_refresh_failure_uses_fresh_current_but_returns_nonzero(tmp_path: Path) -> None:
    scanner, provider = _service(tmp_path, symbols=("AAA", "BBB"))
    initial = scanner.run(bootstrap_days=80)
    assert initial.exit_code == 0
    provider.fail.add("BBB")
    result = scanner.run(bootstrap_days=80)
    rows = {row["symbol"]: row for row in result.snapshot["symbols"]}
    assert result.exit_code == 1
    assert rows["BBB"]["update"]["previous_current_preserved"] is True
    assert rows["BBB"]["freshness"]["status"] == "FRESH"
    assert rows["BBB"]["scan"]["status"]["state"] == "ready"
    assert rows["BBB"]["run_status"] == "failed"


def test_stale_current_suppresses_formal_signal(tmp_path: Path) -> None:
    scanner, provider = _service(tmp_path, now_day=19)
    scanner.run(bootstrap_days=80)
    provider.fail.add("AAA")
    scanner._now = lambda: datetime(2024, 4, 22, 12, tzinfo=UTC)
    result = scanner.run(bootstrap_days=80)
    row = result.snapshot["symbols"][0]
    assert row["run_status"] == "stale"
    assert row["freshness"]["status"] == "STALE_DATA"
    assert row["signals_new"] == 0


def test_scan_only_never_contacts_provider_and_keeps_freshness_gate(tmp_path: Path) -> None:
    scanner, provider = _service(tmp_path)
    scanner.run(bootstrap_days=80)
    request_count = len(provider.requests)
    scanner.refresh_data = False
    result = scanner.run(bootstrap_days=80)
    row = result.snapshot["symbols"][0]
    assert len(provider.requests) == request_count
    assert row["update"]["mode"] == "scan_only"
    assert row["freshness"]["status"] == "FRESH"


def test_keyboard_interrupt_marks_daily_run_interrupted(tmp_path: Path) -> None:
    scanner, _ = _service(tmp_path)

    def interrupt(*args, **kwargs):
        raise KeyboardInterrupt

    scanner._run_symbol = interrupt
    with pytest.raises(KeyboardInterrupt):
        scanner.run()
    with sqlite3.connect(scanner.database_path) as db:
        statuses = [row[0] for row in db.execute("SELECT status FROM daily_runs")]
    assert statuses == ["INTERRUPTED"]


def test_research_data_is_computed_but_never_formally_persisted(tmp_path: Path) -> None:
    scanner, _ = _service(tmp_path)
    bars = _bars(quality="RESEARCH_ONLY")
    bars.attrs["dataset_version"] = "research-v1"

    class Manifest:
        quality_passed = True
        quality_status = "RESEARCH_ONLY"
        quality_score = 75.0
        dataset_version = "research-v1"
        row_count = 80
        data_source = "fake"

    scanner.historical_service.lake.current_version = lambda *args: {"version": "research-v1"}
    scanner.historical_service.update = lambda *args, **kwargs: Manifest()
    scanner.historical_service.load_bars = lambda *args, **kwargs: bars.copy()
    result = scanner.run(research_mode=True)
    row = result.snapshot["symbols"][0]
    assert row["scan"]["status"]["state"] == "ready"
    assert row["alert_policy"]["formal_eligible"] is False
    assert len(row["research_signals"]) == 4
    assert SQLiteDailySignalRepository(result.database_path).signal_count() == 0


def test_notifier_retries_without_duplicate_log_lines(tmp_path: Path) -> None:
    repo = SQLiteDailySignalRepository(tmp_path / "signals.sqlite3")
    event = SignalEvent.create(
        instrument_id="AAA.TEST", symbol="AAA", timeframe="D1",
        signal_type="MACD_GOLDEN_CROSS", direction="LONG",
        signal_time="2024-01-01T00:00:00+00:00", detected_at="2024-01-02T00:00:00+00:00",
        trigger_price=100, reference_value=0, dataset_version="v1",
        indicator_name="macd_12_26_9", indicator_parameters={"fast": 12},
    )
    assert repo.insert_signal(event)
    notifier = LogNotifier(tmp_path / "logs")
    notifier.notify(event)
    notifier.notify(event)
    lines = (tmp_path / "logs" / "2024-01-02.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1


def test_cli_returns_nonzero_for_bad_run(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    class FakeService:
        def __init__(self, **kwargs): pass
        def run(self, **kwargs):
            class Result:
                exit_code = 1
                failed_symbols = ("AAA",)
                snapshot_path = tmp_path / "report.json"
                database_path = tmp_path / "signals.sqlite3"
                signal_log_root = tmp_path / "logs"
                snapshot = {"report_date": "2024-01-01", "symbols": [], "summary": {"failed": 1}}
            return Result()
    monkeypatch.setattr("turtle_detector.daily_cli.DailyMarketScanService", FakeService)
    assert daily_main(["--symbol", "AAA", "--no-color"]) == 1


def test_cli_returns_130_without_traceback_on_keyboard_interrupt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class InterruptedService:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def run(self, **kwargs):
            raise KeyboardInterrupt

    monkeypatch.setattr("turtle_detector.daily_cli.DailyMarketScanService", InterruptedService)
    assert daily_main(["--provider-timeout", "5", "--provider-retries", "1"]) == 130
