"""Golden-master regression for the shared D1 feature and Turtle paths.

The expected JSON is deliberately read-only during ordinary test runs.  Updating
it is a reviewable source change: refresh the fixture, inspect the first event
or order difference, then update this file in the same change set.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pytest

from inv_trend_core.features import FeatureRequest, PreparedBars
from turtle_detector.backtest.engine import DetectorBacktester
from turtle_detector.indicators.daily_signals import analyze_daily_signals
from turtle_detector.models import AssetConfig, Market, StrategyConfig
from turtle_multi_asset import AssetSpec, TurtleBacktester, TurtleRules


FIXTURES = Path(__file__).parent / "fixtures"


def _safe(value: Any) -> Any:
    if isinstance(value, (float, np.floating)):
        # Golden Master accepts the documented 1e-10 numerical tolerance;
        # structural/event changes remain exact through the canonical digest.
        return None if not math.isfinite(value) else round(float(value), 10)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, list):
        return [_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _safe(item) for key, item in value.items()}
    return value


def _digest(value: Any) -> str:
    payload = json.dumps(
        _safe(value), sort_keys=True, default=str, separators=(",", ":"), allow_nan=False
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def _curve_records(curve: pd.Series) -> list[dict[str, object]]:
    return [
        {"timestamp": pd.Timestamp(timestamp).isoformat(), "equity": float(value)}
        for timestamp, value in curve.items()
    ]


def _stable_order_records(orders: pd.DataFrame) -> list[dict[str, object]]:
    """Exclude internal random reservation IDs from strategy-result identity."""
    return orders.drop(columns=["intent_id"], errors="ignore").to_dict("records")


def _asset() -> AssetConfig:
    return AssetConfig(
        symbol="GOLD",
        instrument="GOLD_SPOT",
        market=Market.CRYPTO,
        data_source="fixture",
        timeframes=("D1",),
        adjustment="none",
    )


def _detector_config() -> StrategyConfig:
    return StrategyConfig(
        atr_period=20,
        system1_entry=20,
        system2_entry=55,
        system1_exit=10,
        system2_exit=20,
        volatility_lookback=60,
        trend_ma_period=20,
        long_trend_ma_period=55,
        false_breakout_bars=3,
    )


def _assert_hash(name: str, actual: str, expected: str) -> None:
    assert actual == expected, (
        f"Golden Master mismatch for {name}: expected {expected}, got {actual}. "
        "Inspect the first event/order difference before intentionally updating "
        "tests/fixtures/golden_d1_expected.json."
    )


def test_shared_paths_match_the_frozen_golden_master() -> None:
    fixture = FIXTURES / "golden_d1.csv"
    expected = json.loads((FIXTURES / "golden_d1_expected.json").read_text(encoding="utf-8"))
    _assert_hash("fixture input", hashlib.sha256(fixture.read_bytes()).hexdigest(), expected["input_sha256"])
    bars = pd.read_csv(fixture, parse_dates=["timestamp"]).set_index("timestamp")

    prepared = PreparedBars.build(
        bars,
        FeatureRequest.turtle(
            atr_period=20,
            channel_periods=(20, 55),
            sma_lags=((10, 0), (20, 0)),
        ),
    ).frame
    for name, value in expected["feature_tail"].items():
        assert float(prepared.iloc[-1][name]) == pytest.approx(value, rel=1e-10)

    hashes = expected["hashes"]
    _assert_hash("daily signals", _digest(analyze_daily_signals(bars)), hashes["daily"])

    detector = DetectorBacktester(
        _detector_config(), initial_equity=100_000, cost_bps=5
    ).run(bars, _asset(), "D1")
    detector_events = [
        {
            key: value
            for key, value in event.items()
            if key
            in {
                "signal_type", "raw_signal_type", "direction", "signal_time",
                "trigger_price", "tradeable", "filtered_reasons",
            }
        }
        for event in detector.signals.to_dict("records")
    ]
    _assert_hash("detector events", _digest(detector_events), hashes["detector_events"])
    _assert_hash("detector trades", _digest(detector.trades.to_dict("records")), hashes["detector_trades"])
    _assert_hash("detector equity", _digest(_curve_records(detector.equity_curve)), hashes["detector_equity"])
    assert detector.metrics == pytest.approx(expected["detector_metrics"], rel=1e-10)

    rules = TurtleRules(
        n_period=20,
        fast_entry=20,
        slow_entry=55,
        fast_exit=10,
        slow_exit=20,
        skip_fast_after_win=True,
        max_total_1n_risk_pct=0.12,
    )
    multi = TurtleBacktester(
        {"GOLD": bars},
        {"GOLD": AssetSpec("GOLD", "crypto", "crypto", qty_step=1)},
        rules,
        initial_equity=100_000,
    ).run()
    _assert_hash("multi-asset orders", _digest(_stable_order_records(multi.orders)), hashes["multi_orders"])
    _assert_hash("multi-asset trades", _digest(multi.trades.to_dict("records")), hashes["multi_trades"])
    _assert_hash("multi-asset equity", _digest(_curve_records(multi.equity_curve)), hashes["multi_equity"])
    assert multi.metrics == pytest.approx(expected["multi_metrics"], rel=1e-10)
