"""Turtle indicator calculations."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..models.domain import TurtleRules


def compute_turtle_indicators(bars: pd.DataFrame, rules: TurtleRules) -> pd.DataFrame:
    """Return bars with Wilder N and shifted breakout/exit channels."""

    _require_columns(bars, {"open", "high", "low", "close"})
    out = bars.copy()
    high = out["high"].to_numpy(dtype=float)
    low = out["low"].to_numpy(dtype=float)
    close = out["close"].to_numpy(dtype=float)
    prev_close = np.empty_like(close)
    prev_close[0] = np.nan
    prev_close[1:] = close[:-1]
    true_range = np.nanmax(
        np.vstack(
            [
                high - low,
                np.abs(high - prev_close),
                np.abs(low - prev_close),
            ]
        ),
        axis=0,
    )
    true_range = pd.Series(true_range, index=out.index)
    out["tr"] = true_range
    out["n"] = _wilder_average(true_range, rules.n_period)

    periods = {
        rules.fast_entry,
        rules.slow_entry,
        rules.fast_exit,
        rules.slow_exit,
    }
    for period in periods:
        out[f"high_{period}"] = out["high"].rolling(period).max().shift(1)
        out[f"low_{period}"] = out["low"].rolling(period).min().shift(1)
    if rules.entry_ma_period >= 2:
        out[f"sma_{rules.entry_ma_period}"] = out["close"].rolling(rules.entry_ma_period).mean()

    out.attrs["_turtle_rules_key"] = _indicator_rules_key(rules)
    return out


def _with_indicators(bars: pd.DataFrame, rules: TurtleRules) -> pd.DataFrame:
    required = _indicator_columns(rules)
    if (
        required.issubset(bars.columns)
        and bars.attrs.get("_turtle_rules_key") == _indicator_rules_key(rules)
    ):
        return bars
    return compute_turtle_indicators(bars, rules)


def _indicator_columns(rules: TurtleRules) -> set[str]:
    periods = {
        rules.fast_entry,
        rules.slow_entry,
        rules.fast_exit,
        rules.slow_exit,
    }
    columns = {"tr", "n"}
    for period in periods:
        columns.add(f"high_{period}")
        columns.add(f"low_{period}")
    if rules.entry_ma_period >= 2:
        columns.add(f"sma_{rules.entry_ma_period}")
    return columns


def _indicator_rules_key(rules: TurtleRules) -> tuple[int, int, int, int, int, int]:
    return (
        rules.n_period,
        rules.fast_entry,
        rules.slow_entry,
        rules.fast_exit,
        rules.slow_exit,
        rules.entry_ma_period,
    )


def _wilder_average(values: pd.Series, period: int) -> pd.Series:
    arr = values.to_numpy(dtype=float)
    out = np.full(len(arr), np.nan, dtype=float)
    if len(arr) < period:
        return pd.Series(out, index=values.index)

    seed = arr[:period]
    if not np.all(np.isfinite(seed)):
        return pd.Series(out, index=values.index)
    out[period - 1] = float(np.mean(seed))
    for idx in range(period, len(arr)):
        if np.isfinite(arr[idx]) and np.isfinite(out[idx - 1]):
            out[idx] = (out[idx - 1] * (period - 1) + arr[idx]) / period
    return pd.Series(out, index=values.index)


def _require_columns(df: pd.DataFrame, columns: set[str]) -> None:
    missing = sorted(columns - set(df.columns))
    if missing:
        raise ValueError(f"missing required bar columns: {missing}")
