# 修改说明

更新时间：2026-08-09

本说明对应当前工作区中尚未提交的修改。当前检测到 **12 个文件**发生变化。

## 总体变更

本次修改主要围绕历史行情数据的可靠发布和可审计性展开：

1. 完善数据质量评估，按“请求区间与已验证上市日的较晚者”计算期望起点。Provider 返回的历史数据不足时，头部缺失会被如实统计并触发 fail-closed，不再容忍小范围截断。
2. 防止全部 K 线均未收盘时错误发布 partial 数据；没有完整 K 线时数据集进入 `QUARANTINED`。
3. 增加数据集 Manifest、父版本、清洗规则版本、文件 SHA-256 和质量报告 SHA-256，形成可追溯的发布血缘。
4. 冲突重复数据保留 base/incoming 双方及冲突清单，支持人工选择保留既有数据或采用新数据。
5. current pointer、Catalog 与实际 artifact 使用 root-relative 路径，并增加一致性校验及修复命令，兼容旧版绝对路径。
6. XAU/XAG D1 改为使用 Dukascopy provider-native UTC 日线口径。

## 文件级说明

| 文件 | 修改内容 |
|---|---|
| `historical_data/api.py` | 强化合并、质量发布、冲突审查和版本发布流程；增加数据集 Manifest 生成、provider 可用起始日期记录、现有版本复用、review candidate 保存、审查批准流程，以及 current lineage 修复逻辑。审计同时覆盖 raw/normalized/quality/curated artifact、Manifest、hash 链和 pointer/Catalog 一致性。 |
| `historical_data/audit.py` | 扩展审计范围，检查数据集 Manifest、curated/quality 文件 hash、版本/运行 ID、行数和 dataset_version；增加 legacy 污染 current 指针、缺失 Manifest、Catalog 与 pointer 漂移等问题的报告。 |
| `historical_data/calendar.py` | 明确当前 NYSE 日历是 `RULE_BASED_NYSE_CALENDAR` 近似规则，不是交易所官方日历；无法确认的停牌、临时闭市等情况归类为 `UNKNOWN`。 |
| `historical_data/cli.py` | 新增 `market-data repair-current --symbol ... --timeframe ...` 命令，用于重新对齐 current pointer、Catalog 和数据集血缘。 |
| `historical_data/config/assets.yaml` | XAU、XAG 的会话时区改为 UTC，日线收盘规则改为 `provider_native_utc`，匹配 Dukascopy 原生 D1 数据。 |
| `historical_data/models.py` | 扩展 `Manifest` 字段；新增不可变 `DatasetManifest`；`path_text()` 支持以数据根目录为基准生成可移植的相对路径。 |
| `historical_data/processing.py` | 清洗规则版本升至 `1.1.1`；重新定义 expected window，严格统计上市日后的头部缺失；仅在 Provider 显式提供并验证时记录 `provider_available_start`；缺失区间按请求范围计算。 |
| `historical_data/storage.py` | 增加 dataset manifest、ingestion report 目录；current pointer 使用 root-relative 路径；发布后校验 pointer/Catalog 一致性并在失败时恢复；增加 `repair_current()` 和旧路径兼容解析。 |
| `historical_data/README.md` | 更新数据质量、冲突审查、规则日历、root-relative 路径、Manifest、修复命令以及 XAU/XAG UTC D1 口径的使用说明。 |
| `tests/test_eligibility.py` | 清理未使用的 pytest、类型和阈值导入，并补充文件末尾换行；测试行为未改变。 |
| `tests/test_historical_data.py` | 更新历史数据相关测试以覆盖本次数据质量、审计、发布和血缘规则变化。 |
| `tests/test_trend_stability.py` | 清理未使用变量、导入并补充文件末尾换行；保留趋势稳定性断言逻辑。 |

## 兼容性与注意事项

- 新生成的 Manifest、pointer 和 Catalog 路径以数据根目录为基准，便于迁移数据目录。
- 旧版绝对路径和工程相对路径仍可读取。
- `provider_available_start` 不会从实际返回数据的 `actual_start` 推导。
- 规则型 NYSE 日历只是近似分类器，不应视为官方交易所日历。
- QUARANTINED 或 REVIEW_REQUIRED 数据不会推进正式 current 版本。

## 打包范围

ZIP 包包含项目 Python 源码、配置文件、测试、研究脚本、项目说明和依赖配置；排除虚拟环境、缓存、`.env`、原始/处理后数据、输出结果和其他大体积运行时文件。
