"""Strategy variant scripts package."""
