"""Render an evidence-based comparison from frozen experiment artifacts."""
from __future__ import annotations

import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]


def main():
    output=ROOT/"优化验证"
    evidence=json.loads((output/"前后对比证据.json").read_text(encoding="utf-8"))
    experiment=json.loads((output/"修复后/实验锁定.json").read_text(encoding="utf-8"))
    full=json.loads((output/"修复后/完整回测结果.json").read_text(encoding="utf-8"))
    defaults=next(row for row in evidence['comparisons'] if row['stop_n']==2 and row['pyramid_step_n']==.5)
    candidate=evidence['comparisons'][0]
    benchmark=evidence['kernel_benchmark']
    tests=ET.parse(output/"最终回归.xml").getroot().find('testsuite').attrib
    def pct(value):return f"{value*100:.2f}%"
    rows=[]
    for item in evidence['comparisons']:
        old,new=item['before']['metrics'],item['after']['metrics']
        rows.append(f"| {item['stop_n']} / {item['pyramid_step_n']} | {pct(old['annualized_return'])} → {pct(new['annualized_return'])} | {pct(abs(old['max_drawdown']))} → {pct(abs(new['max_drawdown']))} | {old['sharpe_ratio']:.3f} → {new['sharpe_ratio']:.3f} | {old['trade_count']} → {new['trade_count']} | {pct(item['after']['oos']['annualized_return'])} | {pct(item['after']['holdout']['total_return'])} | {pct(item['stress_holdout']['total_return'])} |")
    windows=full['combinations'][0]['folds']
    periods='\n'.join(f"- 第 {fold['window']['fold']} 折：训练 {fold['window']['train_start'][:10]} 至 {fold['window']['train_end'][:10]}；验证 {fold['window']['validation_start'][:10]} 至 {fold['window']['validation_end'][:10]}。" for fold in windows)
    report=f"""# 代码清理、执行真实性与可视化优化

本次修改已写入源码。比较基线是 Git `332f70e69458b931feeeaacd79fa5cb0aefb95d8`，原有 `.gitignore` 的用户修改未动。
完整交付见 `完整优化代码.zip`；报告可直接离线打开 [新版交互报告](修复后/参数与交易报告.html)，对照 [旧版报告](修改前/参数与交易报告.html)。

## 结论

执行真实性和可复现性有明确改善，但没有证据支持把候选参数替换为生产默认值。
预先锁定的 6 组参数在最后 365 天留出集上全部亏损，`best_combination_id` 均未获得确认。
验证集第一名是 {candidate['stop_n']}N 止损、{candidate['pyramid_step_n']}N 加仓，留出总收益 {pct(candidate['after']['holdout']['total_return'])}；双倍成本后为 {pct(candidate['stress_holdout']['total_return'])}。
因此保留经典 20/55 入场、10/20 通道退出及原生产参数，没有用留出集另选赢家，也没有添加固定止盈来美化收益。

原参数 2N 止损、0.5N 加仓，保持数据、仓位预算与成本一致：

| 指标 | 修改前 | 修复后 |
|---|---:|---:|
| 全样本年化收益 | {pct(defaults['before']['metrics']['annualized_return'])} | {pct(defaults['after']['metrics']['annualized_return'])} |
| 全样本最大回撤幅度 | {pct(abs(defaults['before']['metrics']['max_drawdown']))} | {pct(abs(defaults['after']['metrics']['max_drawdown']))} |
| 全样本 Sharpe | {defaults['before']['metrics']['sharpe_ratio']:.3f} | {defaults['after']['metrics']['sharpe_ratio']:.3f} |
| 完成交易数 | {defaults['before']['metrics']['trade_count']} | {defaults['after']['metrics']['trade_count']} |
| 最终留出总收益 | {pct(defaults['before']['holdout']['total_return'])} | {pct(defaults['after']['holdout']['total_return'])} |

这些变化来自执行修复，不应解释为未来收益预测。修复前的超长持仓和较少交易，部分来自退出单被错误取消。
也存在修复后历史收益下降的组合，见完整比较表；没有筛掉这些结果。

## 清理与职责对比

| 项目 | 修改前 | 修改后 | 依赖与一致性确认 |
|---|---|---|---|
| 普通退出、止损记账 | 两套成本、现金、胜负和交易记录实现 | 单一 `_execute_orders`，保护止损传入触发/跳空价格 | 删除前检查调用点，新增 cash/derivative 下的逐字段等价测试 |
| 入场突破方向 | 策略引擎和投影器各维护一份 | `core/突破规则.py` 共用纯函数 | 50,000 条输入逐项一致，原类方法保留兼容 |
| `_metrics` 包装函数 | 无调用的私有转发 | 删除 | 全库搜索仅有定义 |
| HTML 源码组织 | Python 中的大段压缩 CSS/JS | 独立中文 CSS/JS 资源，最终仍内联为离线 HTML | 在 package-data 中登记；报告渲染和 UI 测试通过 |
| 信号数据 | 新版初稿按每组组合重复嵌入相同信号 | 按信号参数哈希只存一份，各组合引用 | 新增结构回归，避免明细功能成倍膨胀 |
| 交付打包 | 上一轮固定目录的脚本 | 复用同一脚本并支持输出目录和名称 | 不复制另一套打包逻辑 |

只删除已确认无外部调用的私有实现和重复路径；没有因低使用率删除公开兼容入口或历史研究数据。
既有核心指标、每日信号、检测器不随清理改变。执行缺陷修复会改变订单与绩效，单独认证并披露。

## 逐项执行审计

| 领域 | 发现与处理 |
|---|---|
| 入场与信号时序 | 保持完成 K 线确认、下一可交易开盘执行；通道继续排除当前 K 线。共用突破核，避免投影与实际入场漂移 |
| 出场 | **修复**：入场的跳空/通道失效过滤不能取消风险减少型退出；否则应退出的持仓可能被长时间保留 |
| 止损与跳空 | **修复**：开盘已经穿越既有保护止损时，先执行保护退出，再处理加仓；废止已不存在仓位的加仓意图。开盘检查不读取当天 high/low |
| 盘中止损 | 保持多头取较差的 min(open,stop)、空头取较差的 max(open,stop)；开盘后才使用本 K 线 high/low 检查止损 |
| 止盈 | 保留趋势跟随的通道退出和止损，没有新增固定盈利目标；属于策略思想的保留，不是遗漏 |
| 仓位和资金 | **修复**：逐笔成交重新计算开盘权益，反映前一笔费用；现货买单按含手续费和滑点的现金上限、数量步长截断，资金不足不成交 |
| 手续费和滑点 | 保留显式的现金成本等价模型，每边按名义金额扣 cost_bps+slippage_bps，不再在价格上重复扣；用双倍成本单独压力测试 |
| 资金费/借券费 | **修复**：除了扣现金，还归属到实际持有的 PositionUnit，汇入交易和单元净盈亏；加仓前发生的费用不摊给后来单元 |
| 窗口末端 | **修复**：显式 liquidation 的独立回测遵守 evaluation_end；批次训练、验证和留出窗口显式 mark-to-market，不能因行情结束位置不同而偷偷改变规则 |
| 异常参数 | 非有限初始资金/权重、非整数验证长度明确拒绝；重叠验证窗口拒绝，防止同一段收益被重复复合 |
| 排名与缺失值 | **修复**：相同指标同分、缺失指标安全计分；缺失留出收益不再当作零收益通过 |
| 样本外隔离 | **修复**：参数邻域只依赖验证集；未来全样本破产标记不参与验证资格。留出仅能否决原候选，不能换选其他候选 |

保护止损采用不利跳空价的依据：触发价格不保证成交价格，见 [Investor.gov 的止损订单说明](https://www.investor.gov/introduction-investing/investing-basics/glossary/stop-order)。
历史模拟不能替代真实执行，见 [CFTC 对模拟交易结果的说明](https://www.cftc.gov/LearnAndProtect/AdvisoriesAndArticles/fraudadv_tradingsystem.html)。

本次历史源为 Binance **现货** BTC/ETH OHLCV，故研究计划采用 cash、禁止做空；不把无资金费数据的现货曲线包装成永续合约实测。
手续费 10 bps/边、滑点 5 bps/边是预先固定的研究假设，非账户真实费率；压力测试为 20+10 bps/边。
仍未模拟订单簿深度、部分成交、排队、流动性冲击、借券可用性、合约强平或盘中资金费时点。现有 intraday 触发选项也不代表逐笔盘中撮合。
因此本次证明的是日线模型的真实性改进，而非交易所级仿真完备。

## 历史验证设计与所有参数结果

数据：BTC、ETH 各 {experiment['data']['BTC']['bars']} 条日线，{experiment['data']['BTC']['start'][:10]}—{experiment['data']['BTC']['end'][:10]}，共同日历无重复或缺日；SHA-256 记录在各目录的 `实验锁定.json`。
没有下载或拼接本次未知来源的新数据，数据截至 2026-04-20，不代表截至今日的市场。
初始资金 100,000，单品种每单位 1N 风险 0.3%；3 个止损宽度 × 2 个加仓间隔，共 6 组。经典进出场通道固定。
参数计划 `config/真实性审计参数计划.yaml` 在修复前锁定，前后文件哈希一致。

{periods}

最终留出为最后 365 个日线观测，2025-04-21—2026-04-20。
既有固定步长计划留下 249 天不属于上述验证折；这些日期没有伪装成样本外折收益。各窗口从空仓开始，允许此前行情用于指标预热。
验证汇总年化和 Sharpe 为各折统计均值，最大回撤为最差折；复合验证收益是独立重置窗口的统计汇总，不是连续实盘资金曲线。

| 止损 N / 加仓 N | 全样本年化 前→后 | 最大回撤幅度 前→后 | Sharpe 前→后 | 交易数 前→后 | 修复后验证年化 | 留出总收益 | 双倍成本留出 |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

**决策：不部署候选参数，不修改生产默认配置。** 此次已经查看了留出数据，后续研究不能再把同一留出称为未见样本；下一次确认应使用新的未来数据或纸面执行记录。

## 性能与可复现性

- 等价突破核：50,000 条输入，预热后交替测量 7 次。中位耗时 {benchmark['before_seconds']*1000:.3f} ms → {benchmark['after_seconds']*1000:.3f} ms，约 **{benchmark['speedup']:.2f} 倍**。逐条结果一致。
- 整批历史运行耗时记录为 {evidence['elapsed_seconds']['before']:.3f} s → {evidence['elapsed_seconds']['after']:.3f} s；因纠错后交易数量变化且不是严格微基准，不能把它直接解释为纯算法加速。
- HTML 为 {evidence['html_bytes']['before']:,} → {evidence['html_bytes']['after']:,} 字节。新版包含可筛选交易、订单及信号明细，体积与功能需一并比较；明细采用 50 行分页，曲线按像素预算保留分桶极值。
- 修复后独立运行两次，完整结果哈希一致：`{evidence['result_hash']}`。
- 输入数据、计划、实际加载的代码目录和代码内容哈希均锁定。脚本会检查导入位置，避免误把安装环境代码当成 Git 对照。

## 可视化效果

[修改前桌面截图](修改前桌面.png) · [修改后桌面截图](修改后桌面.png) · [移动端交互截图](修改后移动交互.png)

| 之前 | 之后 |
|---|---|
| 首屏大量元数据和原始参数 | 首屏区分验证、留出和全样本指标，元数据收入证据区 |
| 曲线缺少日期/数值轴、无悬停数值 | 日期轴、数值轴、颜色图例、悬停数据和日期范围筛选 |
| 盈亏柱高度可能超出绘图区 | 以零为基线正确缩放正负柱 |
| 只可查看 JSON 组合证据 | 联动已平仓交易、执行/取消/拒绝订单、原始策略信号 |
| 无明细查询和导出 | 搜索、日期筛选、50 行分页、筛选结果 CSV 导出 |
| 任意字符串写 innerHTML | 动态字段使用 textContent，嵌入 JSON 转义结束标签 |
| 缺少实际移动端检验 | 桌面和真实 390px 布局各通过 15 项交互检查，正文无横向溢出 |

Browser 插件当时无连接，验证采用隔离工作区配置的本地无头 Edge，不读取用户浏览器会话。
检查包括组合切换、分页、无结果筛选、订单/信号视图、日期重置、CSV Blob 导出、实际恶意字段、脚本错误和画布尺寸。

## 回归与交付

原始基线 479 项通过；最终 JUnit：{tests['tests']} 项、{tests['failures']} 失败、{tests['errors']} 错误、{tests['skipped']} 跳过。
原 `golden_d1_expected.json` 完全保留；其输入、指标、每日信号和检测器继续按旧基线校验。
只对受执行纠错影响的 multi_* 路径增加 `tests/fixtures/执行真实性修复期望_v1.json`，记录旧文件 SHA、修复原因及首个差异，并用独立执行测试验证业务逻辑。
原黄金样本中多资产订单 23→22、已平仓交易 7→8、CAGR 13.12%→7.05%；没有为了保持旧收益而保留错误退出。

复现命令：

```powershell
.venv/Scripts/python.exe -m pytest -q --basetemp .tmp/独立复验目录
.venv/Scripts/python.exe -m ruff check src tests scripts
.venv/Scripts/python.exe scripts/真实性与参数验证.py --label 独立复验
.venv/Scripts/python.exe scripts/真实性与参数验证.py --label 成本复验 --cost-multiplier 2
.venv/Scripts/python.exe scripts/报告交互自检.py --input 优化验证/修复后/参数与交易报告.html --label 页面复验 --check
```

基线比较需要原 Git 历史，历史研究重跑还需要本地 `processed_data` 中两份原始 CSV；源码包不包含运行行情、密钥、虚拟环境或用户浏览器配置。
报告、完整结果、样本窗口、数据/代码哈希、性能原始样本与测试 XML 均随本次交付保存。
"""
    (output/"优化对比报告.md").write_text(report,encoding="utf-8")
    print(output/"优化对比报告.md")


if __name__=='__main__':
    main()
