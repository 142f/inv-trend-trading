"""Strategy variants package."""
