from __future__ import annotations

import ast
from pathlib import Path


def test_core_does_not_depend_on_io_or_application_packages() -> None:
    root = Path(__file__).parents[1] / "inv_trend_core"
    banned = {
        "historical_data", "inv_trend_application", "inv_trend_observability",
        "turtle_detector", "turtle_multi_asset", "sqlite3", "requests", "urllib",
    }
    violations = []
    for source in root.glob("*.py"):
        tree = ast.parse(source.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            for name in names:
                if name.split(".")[0] in banned:
                    violations.append(f"{source.name}: {name}")
    assert violations == []


def test_application_does_not_depend_on_cli_or_presentation_packages() -> None:
    root = Path(__file__).parents[1] / "inv_trend_application"
    banned = {"argparse", "rich", "webbrowser"}
    violations = []
    for source in root.rglob("*.py"):
        tree = ast.parse(source.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            for name in names:
                if name.split(".")[0] in banned:
                    violations.append(f"{source.name}: {name}")
    assert violations == []


def test_historical_data_does_not_depend_on_strategy_or_application_packages() -> None:
    root = Path(__file__).parents[1] / "historical_data"
    banned = {"inv_trend_application", "turtle_detector", "turtle_multi_asset"}
    violations = []
    for source in root.rglob("*.py"):
        tree = ast.parse(source.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            for name in names:
                if name.split(".")[0] in banned:
                    violations.append(f"{source.name}: {name}")
    assert violations == []
