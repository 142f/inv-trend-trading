# QQQ / SPY Trend Backtest

- Initial equity: 10000.00
- Strategy: single-symbol turtle trend, long-only, max leverage 3x
- Data source: `processed_data/cleaned/data_external_equities`

| Symbol | Window | Status | Test Start | Test End | Trend Final | Trend Return | Trend CAGR | BuyHold Final | BuyHold Return | BuyHold CAGR |
| --- | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| QQQ | 2y | ok | 2024-04-22 | 2026-04-20 | 11891.81 | 18.92% | 9.08% | 15443.15 | 54.43% | 24.36% |
| QQQ | 3y | ok | 2023-04-20 | 2026-04-20 | 15563.78 | 55.64% | 15.88% | 20449.92 | 104.50% | 26.92% |
| QQQ | 5y | ok | 2021-04-20 | 2026-04-20 | 18426.25 | 84.26% | 13.00% | 19226.24 | 92.26% | 13.97% |
| QQQ | 10y | ok | 2016-04-20 | 2026-04-20 | 22834.25 | 128.34% | 8.61% | 58458.97 | 484.59% | 19.32% |
| QQQ | 15y | insufficient_history | 2016-04-20 | 2026-04-20 | - | - | - | - | - | - |
| QQQ | 20y | insufficient_history | 2016-04-20 | 2026-04-20 | - | - | - | - | - | - |
| QQQ | 30y | insufficient_history | 2016-04-20 | 2026-04-20 | - | - | - | - | - | - |
| SPY | 2y | ok | 2024-04-22 | 2026-04-20 | 11844.24 | 18.44% | 8.86% | 14210.76 | 42.11% | 19.28% |
| SPY | 3y | ok | 2023-04-20 | 2026-04-20 | 12824.22 | 28.24% | 8.64% | 17241.43 | 72.41% | 19.91% |
| SPY | 5y | ok | 2021-04-20 | 2026-04-20 | 11947.57 | 19.48% | 3.62% | 17229.30 | 72.29% | 11.50% |
| SPY | 10y | ok | 2016-04-20 | 2026-04-20 | 12233.92 | 22.34% | 2.04% | 33800.10 | 238.00% | 12.95% |
| SPY | 15y | insufficient_history | 2016-04-20 | 2026-04-20 | - | - | - | - | - | - |
| SPY | 20y | insufficient_history | 2016-04-20 | 2026-04-20 | - | - | - | - | - | - |
| SPY | 30y | insufficient_history | 2016-04-20 | 2026-04-20 | - | - | - | - | - | - |

`insufficient_history` means the local cleaned dataset does not have enough years to support that window.